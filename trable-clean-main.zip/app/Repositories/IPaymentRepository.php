<?php
 
namespace App\Repositories;

interface IPaymentRepository
{

  
}
