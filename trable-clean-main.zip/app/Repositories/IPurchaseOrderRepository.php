<?php
 
namespace App\Repositories;

interface IPurchaseOrderRepository
{

  
}
