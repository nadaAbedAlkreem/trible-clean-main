<?php
 
namespace App\Repositories;

interface IUpdateRepository
{

  
}
