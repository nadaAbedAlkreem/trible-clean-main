<?php
 
namespace App\Repositories;

interface IRepresentativeRepository
{

  
}
