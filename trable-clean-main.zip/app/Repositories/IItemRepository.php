<?php
 
namespace App\Repositories;

interface IItemRepositoryRepository
{

  
}
