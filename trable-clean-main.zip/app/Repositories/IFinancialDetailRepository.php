<?php


namespace App\Repositories;

interface IFinancialDetailRepository
{

  
}
