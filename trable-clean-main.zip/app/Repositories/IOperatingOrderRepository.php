<?php
 
namespace App\Repositories;

interface IOperatingOrderRepository
{

  
}
