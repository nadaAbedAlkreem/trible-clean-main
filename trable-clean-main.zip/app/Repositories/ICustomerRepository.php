<?php


namespace App\Repositories;

interface ICustomerRepository
{

  
}
