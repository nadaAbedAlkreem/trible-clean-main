<?php

namespace App\Repositories;

interface INoteRepository
{

  
}