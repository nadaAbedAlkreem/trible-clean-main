 
		<!-- JQuery min js -->
		<script src="<?php echo e(url('assets/plugins/jquery/jquery.min.js')); ?>"></script>

		<!-- Bootstrap Bundle js -->
		<script src="<?php echo e(url('assets/plugins/bootstrap/js/popper.min.js')); ?>"></script>
		<script src="<?php echo e(url('assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>

		<!--Internal  Chart.bundle js -->
		<script src="<?php echo e(url('assets/plugins/chart.js/Chart.bundle.min.js')); ?>"></script>



		<!-- Moment js -->
		<script src="<?php echo e(url('assets/plugins/moment/moment.js')); ?>"></script>

		<!--Internal Sparkline js -->
		<script src="<?php echo e(url('assets/plugins/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>

		<!-- Moment js -->
		<script src="<?php echo e(url('assets/plugins/raphael/raphael.min.js')); ?>"></script>

		<!--Internal Apexchart js-->
		<script src="<?php echo e(url('assets/js/apexcharts.js')); ?>"></script>

		<!--Internal  Perfect-scrollbar js -->
		<script src="<?php echo e(url('assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
		<script src="<?php echo e(url('assets/plugins/perfect-scrollbar/p-scroll.js')); ?>"></script>

		<!-- Eva-icons js -->
		<script src="<?php echo e(url('assets/js/eva-icons.min.js')); ?>"></script>

		<!-- right-sidebar js -->
		<script src="<?php echo e(url('assets/plugins/sidebar/sidebar.js')); ?>"></script>
		<script src="<?php echo e(url('assets/plugins/sidebar/sidebar-custom.js')); ?>"></script>

		<!-- Sticky js -->
		<script src="<?php echo e(url('assets/js/sticky.js')); ?>"></script>
		<script src="<?php echo e(url('assets/js/modal-popup.js')); ?>"></script>

		<!-- Left-menu js-->
		<script src="<?php echo e(url('assets/plugins/side-menu/sidemenu.js')); ?>"></script>

		<!-- Internal Map -->
		<script src="<?php echo e(url('assets/plugins/jqvmap/jquery.vmap.min.js')); ?>"></script>
		<script src="<?php echo e(url('assets/plugins/jqvmap/maps/jquery.vmap.usa.js')); ?>"></script>

		<!--Internal  index js -->
		<script src="<?php echo e(url('assets/js/index.js')); ?>"></script>

		<!--themecolor js-->
		<script src="<?php echo e(url('assets/js/themecolor.js')); ?>"></script>

		<!-- Apexchart js-->
		<script src="<?php echo e(url('assets/js/apexcharts.js')); ?>"></script>
		<script src="<?php echo e(url('assets/js/jquery.vmap.sampledata.js')); ?>"></script>

		<!-- custom js -->
		<script src="<?php echo e(url('assets/js/custom.js')); ?>"></script>

		<!-- switcher-styles js -->
		<script src="<?php echo e(url('assets/js/swither-styles.js')); ?>"></script>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
		<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
         <!-- TinyMCE CDN -->
        <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
		<script src = "ckeditor/ckeditor.js"></script>

        <script>
          tinymce.init({
            selector: 'textarea#content',
          });
        </script>
  	<script src="<?php echo e(url('assets/plugins/fileuploads/js/fileupload.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/fileuploads/js/file-upload.js')); ?>"></script>

		<!--Internal Fancy uploader js-->
		<script src="<?php echo e(url('assets/plugins/fancyuploder/jquery.ui.widget.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/fancyuploder/jquery.fileupload.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/fancyuploder/jquery.iframe-transport.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/fancyuploder/jquery.fancy-fileupload.js')); ?>"></script>
        <script src="<?php echo e(url('assets/plugins/fancyuploder/fancy-uploader.js')); ?>"></script><script src="assets/plugins/jquery/jquery.min.js"></script>
	<script src="<?php echo e(url('assets/plugins/bootstrap/popper.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/bootstrap/bootstrap-slider.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/tether/js/tether.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/raty/jquery.raty-fa.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/slick/slick.min.js')); ?>"></script>
	<script src="<?php echo e(url('assets/plugins/jquery-nice-select/js/jquery.nice-select.min.js')); ?>"></script>
	<script src="<?php echo e(url('https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU')); ?>" defer></script>
	<script src="<?php echo e(url('assets/plugins/google-map/map.js')); ?>" defer></script>
 	<script src="<?php echo e(url('https://unpkg.com/aos@next/dist/aos.js')); ?>"></script>
	<script src="<?php echo e(url('https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js')); ?>" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

	<?php /**PATH C:\xampp\htdocs\E-CommerceApi\resources\views/dashboard/asset/js.blade.php ENDPATH**/ ?>