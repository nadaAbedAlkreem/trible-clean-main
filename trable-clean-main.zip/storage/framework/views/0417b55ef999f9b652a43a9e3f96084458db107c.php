<link rel="stylesheet" href="<?php echo e(asset('assets/Triple Clean_files/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/Triple Clean_files/print.css')); ?>" type="text/css" media="print">
    <link rel="stylesheet" href="<?php echo e(asset('assets/Triple Clean_files/main.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/scrollbar/scroll.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/alertify/alertify.min.css')); ?>">
         



<!-- test -->


<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon3.png')); ?>">
		
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.rtl.min.css')); ?>">
		
		<!-- animation CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">
		
		  	<!-- Select2 CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">


		<!-- Datatable CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>">
		
		<!-- Fontawesome CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">
		
        <!-- Font CSS -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/fatawa_font.css')); ?>"/> 
        <!-- Font CSS -->

     

		<!-- Main CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
		

     

		<!-- dropzone CSS -->
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/dropzone.css')); ?>">
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/details.css')); ?>">


     <?php /**PATH C:\xampp\htdocs\trable-clean-main\resources\views/dashboard/asset/css.blade.php ENDPATH**/ ?>