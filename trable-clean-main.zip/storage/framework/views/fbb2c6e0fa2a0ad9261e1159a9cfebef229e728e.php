<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							<li >
								<a href="" ><img src="assets/img/icons/dashboard.svg" alt="img"><span>  لوحة التحكم </span> </a>
							</li>
			
							<li class="submenu">
								<a href="javascript:void(0);"><img src="assets/img/icons/settings.svg" alt="img"><span> اوامر التشغيل   </span> <span class="menu-arrow"></span></a>
								<ul>
									<li><a href="<?php echo e(route('details')); ?>">تفاصيل اوامر التشغيل </a></li>
 								 
								</ul>
							</li>


							<li class="submenu">
					        <div class="header-left active"> 			
								<a href="" class ="logo">	
									<img src="<?php echo e(asset('assets/img/logo2.jpg')); ?>" alt="img">
								</a>
							</div>
							</li>
						</ul>
					</div>
				</div>
			</div><?php /**PATH C:\xampp\htdocs\trable-clean-main\resources\views/dashboard/components/sidebar.blade.php ENDPATH**/ ?>