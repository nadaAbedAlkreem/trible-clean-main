<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">

<!-- Favicon -->
<link rel="icon" href="<?php echo e(url('assets/img/brand/favicon.png')); ?>" type="image/x-icon">

<!-- Icons css -->
<link href="<?php echo e(url('assets/css/icons.css')); ?>" rel="stylesheet">

 
<!-- Bootstrap css -->
<link id="style" href="<?php echo e(url('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/plugins/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">

<!-- style css -->
<link href="<?php echo e(url('assets/dashborad-assets/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/css/plugins.css')); ?>" rel="stylesheet">

<!--- Animations css-->
<link href="<?php echo e(url('assets/css/animate.css')); ?>" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js" integrity="sha512-7VTiy9AhpazBeKQAlhaLRUk+kAMAb8oczljuyJHPsVPWox/QIXDFOnT9DUk1UC8EbnHKRdQowT7sOBe7LAjajQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
         <!-- TinyMCE CDN -->
         <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
		<script src = "ckeditor/ckeditor.js"></script>

        <script>
          tinymce.init({
            selector: 'textarea#content',
          });
        </script>
 <style>
  .btn-waiting{
  background: rgba(255, 168, 0, 0.2);
border-radius: 32px !important;
font-family: Montserrat-Arabic;
padding: 10px !important;
    font-size: 12px !important;
    color:#FFA800
    ;
}
.btn-payment{
  background: rgba(0, 26, 255, 0.2);
  border-radius: 32px !important;
  font-family: Montserrat-Arabic;
  padding: 10px !important;
      font-size: 12px !important;
      color:#001AFF

}
.btn-finish{
  background: rgba(0, 255, 148, 0.2);
  border-radius: 32px !important;
  font-family: Montserrat-Arabic;
  padding: 10px !important;
      font-size: 12px !important;
      color:#00FF94;
      text-align: center !important;

}
  </style>
  <!-- <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

<link href="<?php echo e(url('assets/plugins/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/plugins/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/plugins/slick/slick.css')); ?>" rel="stylesheet">
<link href="<?php echo e(url('assets/plugins/slick/slick-theme.css')); ?>" rel="stylesheet">

<link href="<?php echo e(url('assets/plugins/jquery-nice-select/css/nice-select.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('assets/fonts/Montserrat-Arabic Bold 700.otf')); ?>"> -->
 <?php /**PATH C:\xampp\htdocs\E-CommerceApi\resources\views/dashboard/asset/css.blade.php ENDPATH**/ ?>